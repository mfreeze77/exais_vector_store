from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from pydantic import BaseModel

from .models import CrawlReport, DefinitionRecord, GraphEdge, GraphNode, ParsedPage


def _write_jsonl(path: Path, records: Iterable[BaseModel]) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(record.model_dump_json(exclude_none=True) + "\n")
            count += 1
    return count


def export_corpus(
    output_dir: Path,
    pages: list[ParsedPage],
    nodes: list[GraphNode],
    edges: list[GraphEdge],
    report: CrawlReport,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    sections = [page.section for page in pages if page.section]
    definitions: list[DefinitionRecord] = [item for page in pages for item in page.definitions]

    _write_jsonl(output_dir / "sections.jsonl", (s for s in sections if s is not None))
    _write_jsonl(output_dir / "definitions.jsonl", definitions)
    _write_jsonl(output_dir / "nodes.jsonl", nodes)
    _write_jsonl(output_dir / "edges.jsonl", edges)

    manifest = {
        "schema_version": "1.0",
        "jurisdiction": {"id": "ks-topeka", "name": "City of Topeka, Kansas", "state": "KS"},
        "code": "TMC",
        "root_url": report.root_url,
        "files": {
            "sections": "sections.jsonl",
            "definitions": "definitions.jsonl",
            "nodes": "nodes.jsonl",
            "edges": "edges.jsonl",
            "report": "crawl_report.json",
        },
        "counts": {
            "sections": report.section_count,
            "definitions": report.definition_count,
            "nodes": report.node_count,
            "edges": report.edge_count,
        },
        "graph_edge_types": ["CONTAINS", "REFERENCES", "DEFINES", "HAS_ORDINANCE_HISTORY"],
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (output_dir / "crawl_report.json").write_text(report.model_dump_json(indent=2), encoding="utf-8")
