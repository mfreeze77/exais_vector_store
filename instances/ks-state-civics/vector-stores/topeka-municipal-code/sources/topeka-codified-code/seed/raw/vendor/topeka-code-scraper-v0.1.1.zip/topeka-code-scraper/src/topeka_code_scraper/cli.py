from __future__ import annotations

import asyncio
from pathlib import Path

import typer

from .crawler import MunicipalCodeCrawler
from .exporter import export_corpus

app = typer.Typer(add_completion=False, help="Scrape the Topeka Municipal Code into clean JSONL + GraphRAG graph files.")


@app.command()
def scrape(
    output: Path = typer.Option(Path("output/topeka"), "--output", "-o", help="Output directory."),
    root_url: str = typer.Option("https://topeka.municipal.codes/TMC", help="Crawl root."),
    delay: float = typer.Option(0.75, min=0.0, help="Minimum seconds between request starts."),
    retries: int = typer.Option(4, min=0, max=10, help="Retries for transient errors."),
    timeout: float = typer.Option(30.0, min=1.0, help="HTTP timeout in seconds."),
    max_pages: int | None = typer.Option(None, min=1, help="Optional crawl cap for testing."),
    archive_raw: bool = typer.Option(False, help="Also save fetched HTML under output/raw/."),
    user_agent: str = typer.Option(
        "TopekaCodeScraper/0.1 (public municipal-code indexing)",
        help="HTTP User-Agent header.",
    ),
) -> None:
    """Crawl Topeka Municipal Code and export clean, graph-ready data."""

    async def run() -> None:
        crawler = MunicipalCodeCrawler(
            root_url=root_url,
            delay_seconds=delay,
            retries=retries,
            timeout_seconds=timeout,
            max_pages=max_pages,
            archive_raw=archive_raw,
            raw_dir=output / "raw",
            user_agent=user_agent,
        )
        pages, nodes, edges, report = await crawler.crawl()
        export_corpus(output, pages, nodes, edges, report)
        typer.echo(f"Fetched pages: {report.pages_fetched} ({report.pages_failed} failed)")
        typer.echo(f"Sections: {report.section_count}")
        typer.echo(f"Definitions: {report.definition_count}")
        typer.echo(f"Graph: {report.node_count} nodes / {report.edge_count} edges")
        typer.echo(f"Output: {output.resolve()}")
        if report.pages_fetched == 0:
            typer.echo("Crawl failed: no pages were fetched. See crawl_report.json for details.", err=True)
            raise typer.Exit(code=2)

    asyncio.run(run())


if __name__ == "__main__":
    app()
