from __future__ import annotations

import asyncio
import random
from dataclasses import dataclass
from datetime import UTC, datetime
from email.utils import parsedate_to_datetime

import httpx


@dataclass(slots=True)
class FetchResult:
    url: str
    html: str
    status_code: int
    retrieved_at: datetime


class PoliteRateLimiter:
    def __init__(self, delay_seconds: float) -> None:
        self.delay_seconds = max(0.0, delay_seconds)
        self._lock = asyncio.Lock()
        self._next_allowed = 0.0

    async def wait(self) -> None:
        loop = asyncio.get_running_loop()
        async with self._lock:
            now = loop.time()
            if now < self._next_allowed:
                await asyncio.sleep(self._next_allowed - now)
            self._next_allowed = loop.time() + self.delay_seconds


class HttpFetcher:
    RETRYABLE = {408, 425, 429, 500, 502, 503, 504}

    def __init__(
        self,
        *,
        delay_seconds: float = 0.75,
        timeout_seconds: float = 30.0,
        retries: int = 4,
        user_agent: str = "TopekaCodeScraper/0.1 (public municipal-code indexing)",
    ) -> None:
        self.retries = max(0, retries)
        self.rate_limiter = PoliteRateLimiter(delay_seconds)
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout_seconds),
            follow_redirects=True,
            headers={
                "User-Agent": user_agent,
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "en-US,en;q=0.8",
            },
            limits=httpx.Limits(max_connections=4, max_keepalive_connections=2),
        )

    async def __aenter__(self) -> "HttpFetcher":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.client.aclose()

    async def fetch(self, url: str) -> FetchResult:
        last_error: Exception | None = None
        for attempt in range(self.retries + 1):
            await self.rate_limiter.wait()
            try:
                response = await self.client.get(url)
                if response.status_code == 200:
                    return FetchResult(
                        url=str(response.url),
                        html=response.text,
                        status_code=response.status_code,
                        retrieved_at=datetime.now(UTC),
                    )
                if response.status_code not in self.RETRYABLE:
                    response.raise_for_status()
                delay = self._retry_delay(response, attempt)
                await asyncio.sleep(delay)
            except (httpx.TimeoutException, httpx.TransportError, httpx.HTTPStatusError) as exc:
                last_error = exc
                if attempt >= self.retries:
                    raise
                await asyncio.sleep(min(30.0, (2**attempt) + random.random()))
        raise RuntimeError(f"Failed to fetch {url}") from last_error

    def _retry_delay(self, response: httpx.Response, attempt: int) -> float:
        retry_after = response.headers.get("retry-after")
        if retry_after:
            try:
                return min(60.0, float(retry_after))
            except ValueError:
                try:
                    dt = parsedate_to_datetime(retry_after)
                    seconds = (dt - datetime.now(dt.tzinfo or UTC)).total_seconds()
                    return max(0.0, min(60.0, seconds))
                except Exception:
                    pass
        return min(30.0, (2**attempt) + random.random())
