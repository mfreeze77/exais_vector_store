from __future__ import annotations

import asyncio
from collections import deque
from datetime import UTC, datetime
from pathlib import Path

from .fetcher import HttpFetcher
from .graph import GraphBuilder
from .models import CrawlReport, ParsedPage
from .normalize import BASE_URL, canonicalize_url, sha256_text
from .parser import MunicipalCodeParser


class MunicipalCodeCrawler:
    def __init__(
        self,
        *,
        root_url: str = f"{BASE_URL}/TMC",
        delay_seconds: float = 0.75,
        retries: int = 4,
        timeout_seconds: float = 30.0,
        max_pages: int | None = None,
        archive_raw: bool = False,
        raw_dir: Path | None = None,
        user_agent: str = "TopekaCodeScraper/0.1 (public municipal-code indexing)",
    ) -> None:
        canonical = canonicalize_url(root_url)
        if not canonical:
            raise ValueError("root_url must be under https://topeka.municipal.codes/TMC")
        self.root_url = canonical
        self.delay_seconds = delay_seconds
        self.retries = retries
        self.timeout_seconds = timeout_seconds
        self.max_pages = max_pages
        self.archive_raw = archive_raw
        self.raw_dir = raw_dir
        self.user_agent = user_agent
        self.parser = MunicipalCodeParser()

    async def crawl(self) -> tuple[list[ParsedPage], list, list, CrawlReport]:
        started = datetime.now(UTC)
        queue: deque[str] = deque([self.root_url])
        queued = {self.root_url}
        seen: set[str] = set()
        pages: list[ParsedPage] = []
        failures: list[dict[str, str]] = []

        async with HttpFetcher(
            delay_seconds=self.delay_seconds,
            timeout_seconds=self.timeout_seconds,
            retries=self.retries,
            user_agent=self.user_agent,
        ) as fetcher:
            while queue:
                if self.max_pages is not None and len(seen) >= self.max_pages:
                    break
                url = queue.popleft()
                if url in seen:
                    continue
                seen.add(url)
                try:
                    fetched = await fetcher.fetch(url)
                    page = self.parser.parse(fetched.url, fetched.html, fetched.retrieved_at)
                    pages.append(page)
                    if self.archive_raw:
                        self._archive_html(page, fetched.html)
                    for link in page.internal_links:
                        if link not in seen and link not in queued:
                            queued.add(link)
                            queue.append(link)
                except Exception as exc:  # keep crawl resumable and report individual failures
                    failures.append({"url": url, "error": f"{type(exc).__name__}: {exc}"})

        nodes, edges = GraphBuilder().build(pages)
        finished = datetime.now(UTC)
        report = CrawlReport(
            started_at=started,
            finished_at=finished,
            root_url=self.root_url,
            pages_seen=len(seen),
            pages_fetched=len(pages),
            pages_failed=len(failures),
            section_count=sum(1 for p in pages if p.section),
            definition_count=sum(len(p.definitions) for p in pages),
            node_count=len(nodes),
            edge_count=len(edges),
            failures=failures,
        )
        return pages, nodes, edges, report

    def _archive_html(self, page: ParsedPage, html: str) -> None:
        raw_dir = self.raw_dir or Path("raw")
        raw_dir.mkdir(parents=True, exist_ok=True)
        name = page.path.removeprefix("/TMC").strip("/") or "TMC"
        safe = name.replace("/", "__")
        path = raw_dir / f"{safe}.{sha256_text(html)[:12]}.html"
        path.write_text(html, encoding="utf-8")
